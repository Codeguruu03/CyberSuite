<p align="center">
  <h1 align="center">🛡️ CyberSuite</h1>
  <p align="center">
    <em>A Comprehensive Python-Based Cybersecurity Toolkit</em>
  </p>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.7+-blue.svg" alt="Python Version">
  <img src="https://img.shields.io/badge/License-MIT-green.svg" alt="License">
  <img src="https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey.svg" alt="Platform">
  <img src="https://img.shields.io/badge/Maintained-Yes-brightgreen.svg" alt="Maintained">
</p>

---

## 📖 About

**CyberSuite** is a powerful, user-friendly cybersecurity toolkit that brings essential security testing tools into a single, cohesive Python application. Designed for security professionals, penetration testers, and cybersecurity enthusiasts, CyberSuite simplifies complex security operations with an intuitive command-line interface.

### ✨ Key Features

- 🎨 **Beautiful CLI Interface** - Colorized output with ASCII art banners
- 🛡️ **9 Security Tools** - Comprehensive toolkit for penetration testing and security analysis
- ✅ **Input Validation** - Comprehensive validation to prevent errors
- 🔒 **Security Warnings** - Built-in deprecation warnings for outdated algorithms
- 🚀 **Cross-Platform** - Works on Windows, Linux, and macOS
- 📦 **Easy Installation** - Install with `pip install cybersuite`
- 🎯 **Educational Focus** - Perfect for learning cybersecurity concepts
- 🔐 **Advanced Hashing** - Supports MD5, SHA-1, SHA-256, SHA-512, and BLAKE2b

---

## 🛠️ Tools Included

### 1. 🔐 GuardGenie - Password Generator & Analyzer
Generate strong, unique passwords based on personal details and analyze password strength using entropy-based calculations.

**Features:**
- Generate 100+ password variations
- Entropy-based strength analysis
- Leetspeak transformations
- Common substitutions (i→1, e→3, a→@, etc.)
- Color-coded strength indicators

### 2. 🖼️ StegGenie - Steganography Tool
Hide and extract secret messages within images using LSB (Least Significant Bit) steganography.

**Features:**
- Hide text messages in images
- Hide entire file contents in images
- Extract hidden messages from images
- Supports PNG, JPG, BMP, and more

### 3. 🌐 ScanGenie - Network Scanner
Perform comprehensive network reconnaissance using Nmap integration.

**Features:**
- 9 different scan types (SYN, TCP, UDP, etc.)
- Version detection
- Service identification
- Port state analysis
- Tabular result display

### 4. #️⃣ HashGenie - Hash Generator
Generate cryptographic hashes for messages and files with security warnings for deprecated algorithms.

**Features:**
- MD5, SHA-1, SHA-256 support
- File and message hashing
- Security warnings for broken algorithms
- Hash file export

---

## 📥 Installation

### Method 1: Install from PyPI (Recommended)

```bash
# Install CyberSuite
pip install cybersuite

# Install with WiFi scanning support (optional)
pip install cybersuite[wifi]
```

### Method 2: Install from Source

```bash
# Clone the repository
git clone https://github.com/Codeguruu03/CyberSuite.git
cd CyberSuite

# Install the package
pip install -e .

# Or use the setup script (Linux/macOS)
chmod +x setup.sh
./setup.sh
```

### Prerequisites

- **Python 3.7+** - Required
- **Nmap** - Required for ScanGenie (network scanner)
- **WiFi Adapter** - Optional, for WiFiGenie

### Installing Nmap

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get update
sudo apt-get install nmap
```

**macOS (Homebrew):**
```bash
brew install nmap
```

**Windows:**
Download and install from [nmap.org](https://nmap.org/download.html)

---

## 🚀 Usage

### After pip installation

```bash
# Run CyberSuite main menu
cybersuite

# Or run individual tools directly
guardgenie      # Password Generator
steggenie       # Steganography
scangenie       # Network Scanner
hashgenie       # Hash Generator
sqlgenie        # SQL Injection Tester
wifigenie       # WiFi Scanner
webgenie        # Web Directory Scanner
crackgenie      # Password Cracker
netgenie        # Network Utility
```

### If running from source

```bash
python main.py
```

### Main Menu

You'll be greeted with the main menu:

```
                     _____       _              _____        _  _        
                    / ____|     | |            / ____|      (_)| |       
                   | |      _   | |__    ___  | (___   _   _ _ | |_  ___ 
                   | |      | | | |_ \  / _ \  \___ \ | | | | || __|/ _ \
                   | |____  | |_| |  | ||  __/  ____) || |_| | || |_|  __/
                    \_____|  \__, |_|  | \___| |_____/  \__,_|_| \__|\___|
                              __/ |                                       
                             |___/                                        

Welcome to Cyber-Suite! 🙏

Please select an option:
1. GuardGenie - Password Generator & Analyzer
2. StegGenie - Steganography Tool
3. ScanGenie - Network Scanner (Nmap)
4. HashGenie - Hash Generator
5. SQLGenie - SQL Injection Tester
6. WiFiGenie - WiFi Network Scanner
7. WebGenie - Web Directory Scanner
8. CrackGenie - Password Hash Cracker
9. NetGenie - Network Utility (Netcat)
10. Quit
```

---

## 📚 Tool Usage Examples

### 🔐 GuardGenie - Password Generator

```bash
# Start GuardGenie
Select option 1 from main menu

# Example usage:
First name: John
Last name: Smith
Birthdate (YYYY-MM-DD): 1990-05-15
[skip other questions by pressing Enter]

# Output: Table with generated passwords and strength ratings
```

**Sample Output:**
```
Password                    | Strength
----------------------------|-------------
JohnSmith                  | Moderate
JohnSmith123               | Strong
Sm1th@1990                 | Very Strong
John$mith                  | Strong
```

---

### 🖼️ StegGenie - Steganography

#### Hiding a Message:
```bash
# Select option 2 from main menu
Choose an option:
1. Hide text in an image
2. Extract text from an image

# Choose option 1, then:
1. Message
2. File

Enter the message you want to hide: Secret meeting at midnight
Enter the path to the image: photo.png

# Output: photo_hidden.png created
```

#### Extracting a Message:
```bash
# Choose option 2
Enter the path to the image: photo_hidden.png

# Output: Extracted text from the image: Secret meeting at midnight
```

---

### 🌐 ScanGenie - Network Scanner

```bash
# Select option 3 from main menu
Enter the target IP address or hostname: 192.168.1.1

Choose a scan type:
1. SYN scan
2. TCP connect scan
3. UDP scan
[... more options ...]

Enter the option number: 2

# Output: Tabular display of open ports, services, and versions
```

**Sample Output:**
```
Host          | State | Protocol | Port | Service | Version
--------------|-------|----------|------|---------|----------
192.168.1.1   | up    | tcp      | 22   | ssh     | OpenSSH 7.9
192.168.1.1   | up    | tcp      | 80   | http    | nginx 1.18
```

---

### #️⃣ HashGenie - Hash Generator

#### Hash a Message:
```bash
# Select option 4 from main menu
Choose an option:
1. Hash a message
2. Hash a file

# Select 1
Enter the message to hash: MySecretPassword

Choose a hash algorithm:
1. MD5 (⚠️ Cryptographically broken - for legacy use only)
2. SHA-1 (⚠️ Cryptographically broken - for legacy use only)
3. SHA-256 (✓ Recommended)

# Select 3
Hash value: 5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8
```

#### Hash a File:
```bash
# Select option 2
Enter the path to the file: document.pdf

# Same hash algorithm selection
# Output: Hash saved to document_hash.pdf
```

---

## ⚠️ Security & Legal Disclaimer

> **IMPORTANT:** This tool is intended for **educational purposes** and **authorized security testing only**.

**Legal Requirements:**
- ✅ Only use on systems you own or have explicit permission to test
- ✅ Obtain written authorization before any security testing
- ❌ Unauthorized access to computer systems is illegal

**Security Warnings:**
- MD5 and SHA-1 are **cryptographically broken** - use SHA-256 or higher for security
- Some scan types require **root/administrator privileges**
- Network scans may trigger **IDS/IPS alerts**

**The developers assume NO liability for misuse of this software.**

---

## 🤝 Contributing

Contributions are welcome! Here's how you can help:

1. **Fork the repository**
2. **Create a feature branch** (`git checkout -b feature/AmazingFeature`)
3. **Commit your changes** (`git commit -m 'Add some AmazingFeature'`)
4. **Push to the branch** (`git push origin feature/AmazingFeature`)
5. **Open a Pull Request**

### Development Guidelines

- Follow PEP 8 style guidelines
- Add comprehensive error handling
- Include docstrings for all functions
- Test on multiple platforms when possible
- Update README for new features

---

## 📋 Requirements

```
pywifi
stegano
requests
argparse
tabulate
colorama
pyfiglet
python-nmap
```

---

## 🐛 Known Issues

- WiFi scanning may require elevated privileges on some systems
- Nmap must be installed separately (not included in pip dependencies)
- Some steganography operations may fail with very large files

---

## 🗺️ Roadmap

- [ ] Add GUI interface
- [ ] Implement result export (JSON/CSV)
- [ ] Add more hash algorithms (SHA-512, BLAKE2)
- [ ] Web directory brute-forcing tool
- [ ] SQL injection testing tool
- [ ] Password hash cracking tool
- [ ] Report generation (PDF/HTML)

---

## 📜 License

This project is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

```
MIT License

Copyright (c) 2024 Naman Goyal

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction...
```

---

## 👨‍💻 Author

**Naman Goyal**

- GitHub: [@Codeguruu03](https://github.com/Codeguruu03)
- Project Link: [https://github.com/Codeguruu03/CyberSuite](https://github.com/Codeguruu03/CyberSuite)

---

## 🙏 Acknowledgments

- **Nmap** - Network scanning capabilities
- **Stegano** - LSB steganography implementation
- **Colorama** - Cross-platform colored terminal text
- **PyFiglet** - ASCII art text generation
- All contributors and users of CyberSuite

---

## 📞 Support

If you encounter any issues or have questions:

1. Check the [Issues](https://github.com/Codeguruu03/CyberSuite/issues) page
2. Create a new issue with detailed information
3. Include your OS, Python version, and error messages

---

<p align="center">
  <sub>Built with ❤️ for the cybersecurity community</sub>
</p>

<p align="center">
  ⭐ Star this repository if you find it helpful!
</p>
